Imports System
Imports System.Diagnostics
Public Class clsCobranzaDO
    <DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
    End Sub
End Class
