﻿
Partial Class frmCargaGeneracionCF
    Inherits System.Web.UI.Page

End Class
