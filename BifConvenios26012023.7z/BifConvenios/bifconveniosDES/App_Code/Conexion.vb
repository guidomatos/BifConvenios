Imports Microsoft.VisualBasic

Public Module Conexion

    Public strCadenaConexion As String

End Module

