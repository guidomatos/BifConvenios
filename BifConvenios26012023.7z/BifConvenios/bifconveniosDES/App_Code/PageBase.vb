Namespace BIFConvenios

    Public Class PageBase
        Inherits System.Web.UI.Page

        'Rutina de verificacion de autenticacion de pagina
        Private Sub PageBase_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Init

        End Sub
    End Class
End Namespace
