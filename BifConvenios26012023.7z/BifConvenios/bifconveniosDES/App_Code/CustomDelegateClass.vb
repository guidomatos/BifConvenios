Imports Microsoft.VisualBasic

Public Class CustomDelegateClass
    Public Delegate Sub PageChangedEventHandler(ByVal sender As Object, ByVal e As CustomPageChangeArgs)
End Class
