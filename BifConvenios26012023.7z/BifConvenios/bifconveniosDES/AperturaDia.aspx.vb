﻿
Partial Class AperturaDia
    Inherits System.Web.UI.Page
End Class
